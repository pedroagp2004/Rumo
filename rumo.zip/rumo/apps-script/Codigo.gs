/**
 * Rumo · ponte entre o app e esta planilha.
 * 1. Troque a CHAVE abaixo por uma senha sua (a mesma vai no app, em Ajustes).
 * 2. Execute a função "configurar" uma vez (autoriza o script e cria as abas).
 * 3. Implantar > Nova implantação > App da Web > Executar como: Eu > Quem pode acessar: Qualquer pessoa.
 * 4. Copie o link que termina em /exec e cole no app.
 */
const CHAVE = 'troque-por-uma-senha-sua';

const ABA = 'Lançamentos';
const CAB = ['ID', 'Data', 'Mês', 'Hora', 'Tipo', 'Valor', 'Categoria', 'Descrição', 'Local', 'Pagamento',
             'Criado em', 'Atualizado em', 'Excluído', 'Categoria ID', 'Versão'];

function configurar() {
  const ss = SpreadsheetApp.getActive();
  let sh = ss.getSheetByName(ABA);
  if (!sh) sh = ss.insertSheet(ABA, 0);
  if (sh.getLastRow() === 0) sh.appendRow(CAB);
  sh.setFrozenRows(1);
  sh.getRange('1:1').setFontWeight('bold');
  sh.getRange('A:A').setNumberFormat('@');
  sh.getRange('B:B').setNumberFormat('dd/mm/yyyy');
  sh.getRange('C:D').setNumberFormat('@');
  sh.getRange('F:F').setNumberFormat('"R$" #,##0.00');
  sh.getRange('K:L').setNumberFormat('dd/mm/yyyy hh:mm');
  sh.getRange('N:O').setNumberFormat('@');
  sh.hideColumns(1); sh.hideColumns(14, 2);

  if (!ss.getSheetByName('Config')) { const c = ss.insertSheet('Config'); c.getRange('A1:B1').setValues([['{}', '-1']]); c.hideSheet(); }

  let r = ss.getSheetByName('Resumo');
  if (!r) r = ss.insertSheet('Resumo', 1);
  r.clear();
  r.getRange('A1').setValue('Gastos por categoria e mês').setFontWeight('bold');
  r.getRange('A3').setFormula("=IFERROR(QUERY('" + ABA + "'!A1:O,\"select G, sum(F) where E = 'Gasto' and M = false group by G pivot C label G 'Categoria'\",1),\"Sem dados ainda\")");
  let l = ss.getSheetByName('Locais');
  if (!l) l = ss.insertSheet('Locais', 2);
  l.clear();
  l.getRange('A1').setValue('Onde mais gastei (geral)').setFontWeight('bold');
  l.getRange('A3').setFormula("=IFERROR(QUERY('" + ABA + "'!A1:O,\"select I, count(A), sum(F) where E = 'Gasto' and M = false and I <> '' group by I order by sum(F) desc limit 50 label I 'Local', count(A) 'Vezes', sum(F) 'Total'\",1),\"Sem dados ainda\")");
}

// Se você corrigir algo direto na planilha (valor, data, descrição, local), o app recebe a correção.
function onEdit(e) {
  const sh = e.range.getSheet();
  if (sh.getName() !== ABA || e.range.getColumn() === 15) return;
  const tz = Session.getScriptTimeZone();
  for (let r = Math.max(2, e.range.getRow()); r < e.range.getRow() + e.range.getNumRows(); r++) {
    if (!sh.getRange(r, 1).getValue()) continue;
    const d = sh.getRange(r, 2).getValue();
    if (d instanceof Date) sh.getRange(r, 3).setValue(Utilities.formatDate(d, tz, 'yyyy-MM'));
    sh.getRange(r, 12).setValue(new Date());
    sh.getRange(r, 15).setValue(String(Date.now()));
  }
}

function doGet(e) {
  const p = (e && e.parameter) || {};
  if (p.chave !== CHAVE) return json({ ok: false, erro: 'chave incorreta' });
  return json({ ok: true, msg: 'Rumo conectado a ' + SpreadsheetApp.getActive().getName() });
}

function doPost(e) {
  let body;
  try { body = JSON.parse(e.postData.contents); } catch (err) { return json({ ok: false, erro: 'pedido inválido' }); }
  if (body.chave !== CHAVE) return json({ ok: false, erro: 'chave incorreta' });
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(20000)) return json({ ok: false, erro: 'planilha ocupada, tente de novo' });
  try {
    const ss = SpreadsheetApp.getActive();
    if (!ss.getSheetByName(ABA)) configurar();
    const sh = ss.getSheetByName(ABA);
    const cfg = salvarConfig(ss, body.config);
    gravar(sh, body.txns || [], cfg);
    return json({ ok: true, txns: ler(sh), config: cfg });
  } catch (err) {
    return json({ ok: false, erro: String(err.message || err) });
  } finally {
    lock.releaseLock();
  }
}

function salvarConfig(ss, cfg) {
  const sh = ss.getSheetByName('Config');
  const atual = Number(sh.getRange('B1').getValue());
  if (cfg && Number(cfg.versao) > atual) {
    sh.getRange('A1:B1').setValues([[JSON.stringify(cfg), String(cfg.versao)]]);
    return cfg;
  }
  try { return JSON.parse(sh.getRange('A1').getValue()); } catch (e) { return cfg; }
}

function linha(t, cfg) {
  const cat = ((cfg && cfg.cats) || []).find(c => c.id === t.cat);
  const [y, m, d] = String(t.data).split('-').map(Number);
  return [t.id, new Date(y, m - 1, d), String(t.data).slice(0, 7), t.hora || '', t.tipo === 'receita' ? 'Entrada' : 'Gasto',
          (t.valor || 0) / 100, cat ? cat.nome : t.cat, t.desc || '', t.local || '', t.pag || '',
          new Date(t.criado), new Date(t.atualizado), !!t.excluido, t.cat, String(t.atualizado)];
}

function gravar(sh, txns, cfg) {
  if (!txns.length) return;
  const n = sh.getLastRow() - 1;
  const ids = n > 0 ? sh.getRange(2, 1, n, 1).getValues().map(r => String(r[0])) : [];
  const vers = n > 0 ? sh.getRange(2, 15, n, 1).getValues().map(r => Number(r[0])) : [];
  const pos = {}; ids.forEach((id, i) => pos[id] = i);
  const novas = [];
  txns.forEach(t => {
    const i = pos[t.id];
    if (i === undefined) novas.push(linha(t, cfg));
    else if (Number(t.atualizado) > vers[i]) sh.getRange(i + 2, 1, 1, CAB.length).setValues([linha(t, cfg)]);
  });
  if (novas.length) sh.getRange(sh.getLastRow() + 1, 1, novas.length, CAB.length).setValues(novas);
}

function ler(sh) {
  const n = sh.getLastRow() - 1;
  if (n <= 0) return [];
  const tz = Session.getScriptTimeZone();
  return sh.getRange(2, 1, n, CAB.length).getValues().filter(r => r[0]).map(r => ({
    id: String(r[0]),
    data: r[1] instanceof Date ? Utilities.formatDate(r[1], tz, 'yyyy-MM-dd') : String(r[1]),
    hora: r[3] instanceof Date ? Utilities.formatDate(r[3], tz, 'HH:mm') : String(r[3]),
    tipo: r[4] === 'Entrada' ? 'receita' : 'despesa',
    valor: Math.round(Number(r[5]) * 100),
    cat: String(r[13] || ''),
    desc: String(r[7] || ''),
    local: String(r[8] || ''),
    pag: String(r[9] || ''),
    criado: r[10] instanceof Date ? r[10].getTime() : Number(r[10]) || 0,
    atualizado: Number(r[14]) || 0,
    excluido: r[12] === true || r[12] === 'TRUE'
  }));
}

function json(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
