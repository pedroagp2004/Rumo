# Rumo · guia de instalação

O Rumo tem duas partes: o app (estes arquivos, hospedados de graça no GitHub Pages) e a planilha Google que guarda tudo. São uns 15 minutos no computador, feitos uma vez só.

## 1. Criar a planilha e o link de sincronização (5 min)

1. Abra o Google Planilhas e crie uma planilha em branco chamada **Rumo**.
2. Menu **Extensões > Apps Script**. Apague o código que aparece e cole todo o conteúdo do arquivo `apps-script/Codigo.gs`.
3. Na linha `const CHAVE = 'troque-por-uma-senha-sua';`, troque o texto entre aspas por uma senha sua (ex.: `rumo-pp-7392`). Salve (ícone de disquete).
4. No seletor de funções no topo, escolha **configurar** e clique em **Executar**. O Google vai pedir autorização: escolha sua conta, clique em "Avançado" e "Acessar Rumo (não seguro)". Isso aparece porque o script é seu e não passou por verificação do Google; ele só mexe nesta planilha.
5. Clique em **Implantar > Nova implantação**. Em "Tipo", escolha **App da Web**. Executar como: **Eu**. Quem pode acessar: **Qualquer pessoa**. Clique em Implantar.
6. Copie o **URL do app da Web** (termina em `/exec`). Guarde junto com a senha.

A planilha passa a ter as abas **Lançamentos** (um gasto por linha), **Resumo** (gastos por categoria em cada mês) e **Locais** (onde você mais gasta).

## 2. Publicar o app no GitHub Pages (5 min)

1. Crie uma conta em github.com, se ainda não tiver.
2. Clique em **New repository**, nome `rumo`, marque **Public** e crie.
3. Na página do repositório, clique em **uploading an existing file** e arraste **o conteúdo** desta pasta (`index.html`, `manifest.webmanifest`, `sw.js` e a pasta `icons`). A pasta `apps-script` e este guia não são necessários. Clique em **Commit changes**.
4. Vá em **Settings > Pages**. Em "Branch", escolha `main` e `/ (root)` e salve.
5. Em um ou dois minutos o app fica em `https://SEU-USUARIO.github.io/rumo/`.

O link é público, mas os dados não ficam no GitHub: ficam no seu celular e na sua planilha, protegidos pela senha.

## 3. Instalar no celular

- **iPhone (Safari):** abra o link, toque em Compartilhar e em **Adicionar à Tela de Início**.
- **Android (Chrome):** abra o link, menu ⋮ e **Instalar app** (ou "Adicionar à tela inicial").

Abra o Rumo pelo ícone, vá em **Ajustes**, cole o link `/exec` e a senha e toque em **Salvar e sincronizar**. O indicador no topo muda para "Na planilha".

## Como usar no dia a dia

- Toque no **+**, digite o valor, escolha o local e a categoria e salve. Depois da primeira vez num lugar, tocar na sugestão do local já preenche categoria e forma de pagamento.
- Sem internet, o gasto fica salvo no celular e sobe sozinho quando a conexão voltar (bolinha amarela = pendente).
- Corrigiu algo direto na planilha (valor, data, descrição, local)? O app recebe a correção na próxima abertura.
- Em **Ajustes** você renomeia categorias, cria novas, define limite mensal por categoria e importa CSV do seu controle antigo.

## Problemas comuns

- **"chave incorreta":** a senha no app é diferente da que está no script.
- **"não consegui acessar o link":** confira se copiou o URL que termina em `/exec` e se o acesso está como "Qualquer pessoa".
- **Mudei o código do script:** use **Implantar > Gerenciar implantações > editar > Nova versão**, assim o link continua o mesmo.
